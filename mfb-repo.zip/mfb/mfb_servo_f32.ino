// =============================================================================
// mfb_servo_f32.ino — Teensy 4.x MFB Servo Controller (OpenAudio F32 build)
//
// Library: github.com/chipaudette/OpenAudio_ArduinoLibrary
// Differences vs int16 build:
//   - 32-bit I2S slots: PCM1808 24-bit arrives intact (current-sense floor)
//   - float blocks end-to-end; no int16 conversion inside the loop
//   - 48 kHz / 16-sample blocks set at runtime via AudioSettings_F32
//
// Hardware unchanged (wiring diagram rev 3):
//   PCM1808 I2S in: L = INA240 current sense, R = program audio
//   UDA1334A I2S out L -> Class D sub amp; ADXL326 Z -> RC -> A0
//
// Bench check on first boot: scope BCLK vs LRC — 32 BCLK per LRC half-cycle
// confirms 24-in-32 framing. If sample rate isn't 48 k on your library
// version, un-comment the setI2SFreq() fallback in setup().
//
// Set RE_OHMS to DMM-measured series-coil Re. Amp volume fixed after cal.
// =============================================================================

#include <Audio.h>
#include <OpenAudio_ArduinoLibrary.h>
#include <ADC.h>
#include <EEPROM.h>
#include <utility/imxrt_hw.h>
#include <math.h>

// ------------------------------- Config -------------------------------------
static const float    FS_AUDIO      = 48000.0f;
static const int      BLOCK_SIZE    = 16;      // 333 us feedback granularity
static const int      ACCEL_PIN     = A0;
static const float    RE_OHMS       = 6.4f;    // <-- DMM-measured, series coils
static const float    CAL_AMP       = 0.10f;   // sweep level, fraction of FS
static const float    TARGET_QC     = 0.50f;
static const float    ACCEL_HPF_HZ  = 5.0f;
static const float    VEL_LEAK_HZ   = 2.0f;
static const uint32_t SETTLE_MS     = 250;
static const uint32_t MEASURE_MS    = 400;

static const float CAL_FREQS[] = {
  10, 13, 16, 20, 24, 28, 32, 36, 40, 44, 48, 52, 56, 60, 65, 70,
  76, 82, 90, 100, 112, 125, 140, 160, 180, 200, 250, 315, 400,
  800, 1400, 2000
};
static const int N_FREQS = sizeof(CAL_FREQS) / sizeof(CAL_FREQS[0]);

AudioSettings_F32 audioCfg(FS_AUDIO, BLOCK_SIZE);

// ------------------- SAI clock fallback (older lib versions) ----------------
static void setI2SFreq(int freq) {
  int n1 = 4;
  int n2 = 1 + (24000000 * 27) / (freq * 256 * n1);
  double C = ((double)freq * 256 * n1 * n2) / 24000000;
  int c0 = (int)C, c2 = 10000;
  int c1 = (int)(C * c2) - (c0 * c2);
  set_audioClock(c0, c1, c2, true);
  CCM_CS1CDR = (CCM_CS1CDR & ~(CCM_CS1CDR_SAI1_CLK_PRED_MASK | CCM_CS1CDR_SAI1_CLK_PODF_MASK))
             | CCM_CS1CDR_SAI1_CLK_PRED(n1 - 1)
             | CCM_CS1CDR_SAI1_CLK_PODF(n2 - 1);
}

// --------------------------- Accel acquisition ------------------------------
ADC adc;
IntervalTimer accelTimer;
static const uint32_t RING_SZ  = 1024;
static const uint32_t RING_MSK = RING_SZ - 1;
volatile int32_t  accelRing[RING_SZ];
volatile uint32_t accelWr = 0;
volatile int32_t  accelDC = 2048;

static void accelISR() {
  accelRing[accelWr & RING_MSK] = (int32_t)adc.adc0->analogReadContinuous() - accelDC;
  accelWr++;
}

// ------------------------------ Biquad --------------------------------------
struct Biquad {
  float b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
  inline float process(float x) {
    float y = b0 * x + z1;
    z1 = b1 * x - a1 * y + z2;
    z2 = b2 * x - a2 * y;
    return y;
  }
  void setHighpass(float f, float Q, float fs) {
    float w = 2.0f * (float)M_PI * f / fs, c = cosf(w), s = sinf(w);
    float al = s / (2.0f * Q), a0 = 1.0f + al;
    b0 = (1 + c) / 2 / a0;  b1 = -(1 + c) / a0;  b2 = b0;
    a1 = (-2 * c) / a0;     a2 = (1 - al) / a0;
    z1 = z2 = 0;
  }
};

// ------------------------------ Goertzel ------------------------------------
struct Goertzel {
  float coeff = 0, cw = 0, sw = 0, s1 = 0, s2 = 0;
  uint32_t n = 0;
  void init(float f, float fs) {
    float w = 2.0f * (float)M_PI * f / fs;
    cw = cosf(w); sw = sinf(w); coeff = 2.0f * cw;
    s1 = s2 = 0; n = 0;
  }
  inline void feed(float x) { float s0 = x + coeff * s1 - s2; s2 = s1; s1 = s0; n++; }
  void result(float &re, float &im) { re = s1 - s2 * cw; im = s2 * sw; }
  float mag()   { float re, im; result(re, im); return sqrtf(re * re + im * im) / (n ? n : 1); }
  float phase() { float re, im; result(re, im); return atan2f(im, re); }
};

// --------------------------- Servo audio object -----------------------------
class MfbServo : public AudioStream_F32 {
public:
  enum Mode { IDLE, CAL, RUN };
  MfbServo(const AudioSettings_F32 &s)
    : AudioStream_F32(2, inQueue), fs(s.sample_rate_Hz), blk(s.audio_block_samples) {}

  void calStart(float freq) {
    gRef.init(freq, fs); gAcc.init(freq, fs); gCur.init(freq, fs);
    phase = 0.0f;
    phaseInc = 2.0f * (float)M_PI * freq / fs;
    calSettleSamps  = (uint32_t)(SETTLE_MS  * fs / 1000.0f);
    calMeasureSamps = (uint32_t)(MEASURE_MS * fs / 1000.0f);
    calDone = false;
    mode = CAL;
  }
  bool calFinished() { return calDone; }
  void getCal(float &refM, float &accM, float &accP, float &curM, float &curP) {
    refM = gRef.mag();
    accM = gAcc.mag();  accP = gAcc.phase() - gRef.phase();
    curM = gCur.mag();  curP = gCur.phase() - gRef.phase();
  }

  void setLoop(float kVel, float rampSec) {
    kVelTarget = kVel;
    kVelStep   = kVel / (rampSec * fs);
    kVel_      = 0.0f;
    hpf.setHighpass(ACCEL_HPF_HZ, 0.707f, fs);
    velLeak = expf(-2.0f * (float)M_PI * VEL_LEAK_HZ / fs);
    vel = 0;
    mode = RUN;
  }
  void setIdle() { mode = IDLE; }

  virtual void update() {
    audio_block_f32_t *prog = AudioStream_F32::receiveReadOnly_f32(0);
    audio_block_f32_t *cur  = AudioStream_F32::receiveReadOnly_f32(1);
    audio_block_f32_t *out  = AudioStream_F32::allocate_f32();
    if (!out) {
      if (prog) AudioStream_F32::release(prog);
      if (cur)  AudioStream_F32::release(cur);
      return;
    }
    out->length = blk;

    // accel ring, block-aligned; resync on overrun, hold-last on underrun
    uint32_t avail = accelWr - accelRd;
    if (avail > (uint32_t)blk + 8) accelRd = accelWr - blk;
    for (int i = 0; i < blk; i++) {
      if (accelRd != accelWr) { lastAccel = accelRing[accelRd & RING_MSK]; accelRd++; }
      accelBlk[i] = (float)lastAccel * (1.0f / 2048.0f);
    }

    switch (mode) {
      case CAL:
        for (int i = 0; i < blk; i++) {
          float s = sinf(phase);
          phase += phaseInc; if (phase > 2.0f * (float)M_PI) phase -= 2.0f * (float)M_PI;
          out->data[i] = s * CAL_AMP;
          if (calSettleSamps) { calSettleSamps--; continue; }
          if (calMeasureSamps) {
            gRef.feed(s);
            gAcc.feed(accelBlk[i]);
            gCur.feed(cur ? cur->data[i] : 0.0f);
            if (--calMeasureSamps == 0) calDone = true;
          }
        }
        break;

      case RUN:
        for (int i = 0; i < blk; i++) {
          if (kVel_ < kVelTarget) kVel_ += kVelStep;
          float a = hpf.process(accelBlk[i]);
          vel = velLeak * vel + a * (1.0f / fs);
          float p = prog ? prog->data[i] : 0.0f;
          float y = p - kVel_ * vel * fs;
          if (y >  0.95f) y =  0.95f;
          if (y < -0.95f) y = -0.95f;
          out->data[i] = y;
        }
        break;

      default:
        for (int i = 0; i < blk; i++) out->data[i] = 0.0f;
    }
    AudioStream_F32::transmit(out, 0);
    AudioStream_F32::release(out);
    if (prog) AudioStream_F32::release(prog);
    if (cur)  AudioStream_F32::release(cur);
  }

private:
  audio_block_f32_t *inQueue[2];
  Mode mode = IDLE;
  float fs; int blk;
  Goertzel gRef, gAcc, gCur;
  float phase = 0, phaseInc = 0;
  uint32_t calSettleSamps = 0, calMeasureSamps = 0;
  volatile bool calDone = false;
  uint32_t accelRd = 0;
  int32_t  lastAccel = 0;
  float    accelBlk[128];              // max block size guard
  Biquad hpf;
  float vel = 0, velLeak = 0;
  float kVel_ = 0, kVelTarget = 0, kVelStep = 0;
};

// ----------------------------- Audio graph ----------------------------------
AudioInputI2S_F32   i2sIn(audioCfg);   // ch0 = L = current, ch1 = R = program
AudioOutputI2S_F32  i2sOut(audioCfg);
MfbServo            servo(audioCfg);
AudioConnection_F32 c1(i2sIn, 1, servo, 0);
AudioConnection_F32 c2(i2sIn, 0, servo, 1);
AudioConnection_F32 c3(servo, 0, i2sOut, 0);
AudioConnection_F32 c4(servo, 0, i2sOut, 1);

// ------------------------------ Cal storage ---------------------------------
struct CalData {
  uint32_t magic;
  float fs, qms, qes, qts, r0, le_mH, plantK, kVel, re;
};
static const uint32_t CAL_MAGIC = 0x4D464202;   // v2 = F32 build
static const int      CAL_ADDR  = 0;

static float magAcc[N_FREQS], phAcc[N_FREQS], magZ[N_FREQS];
static CalData cal;

static float interpX(float x0, float x1, float y0, float y1, float yt) {
  if (y1 == y0) return x0;
  return x0 + (x1 - x0) * (yt - y0) / (y1 - y0);
}

static void deriveParameters() {
  int ip = 0;
  for (int i = 1; i < N_FREQS - 3; i++)
    if (magZ[i] > magZ[ip]) ip = i;
  float fsr = CAL_FREQS[ip];
  if (ip > 0 && ip < N_FREQS - 4) {
    float l0 = logf(CAL_FREQS[ip - 1]), l1 = logf(CAL_FREQS[ip]), l2 = logf(CAL_FREQS[ip + 1]);
    float y0 = magZ[ip - 1], y1 = magZ[ip], y2 = magZ[ip + 1];
    float d = (y0 - 2 * y1 + y2);
    if (fabsf(d) > 1e-12f) fsr = expf(l1 - 0.5f * (y2 - y0) / d * ((l2 - l0) / 2));
  }
  cal.fs = fsr;
  float zRe  = magZ[0];
  cal.r0 = magZ[ip] / zRe;
  cal.re = RE_OHMS;

  float zHalf = zRe * sqrtf(cal.r0);
  float f1 = 0, f2 = 0;
  for (int i = 1; i <= ip; i++)
    if (magZ[i - 1] < zHalf && magZ[i] >= zHalf)
      { f1 = interpX(CAL_FREQS[i - 1], CAL_FREQS[i], magZ[i - 1], magZ[i], zHalf); break; }
  for (int i = ip; i < N_FREQS - 3; i++)
    if (magZ[i] >= zHalf && magZ[i + 1] < zHalf)
      { f2 = interpX(CAL_FREQS[i], CAL_FREQS[i + 1], magZ[i], magZ[i + 1], zHalf); break; }
  cal.qms = (f1 > 0 && f2 > f1) ? cal.fs * sqrtf(cal.r0) / (f2 - f1) : 0;
  cal.qes = (cal.r0 > 1.001f && cal.qms > 0) ? cal.qms / (cal.r0 - 1.0f) : 0;
  cal.qts = (cal.qms > 0 && cal.qes > 0) ? cal.qms * cal.qes / (cal.qms + cal.qes) : 0;

  float zHF = magZ[N_FREQS - 1] / zRe * RE_OHMS;
  float x = zHF * zHF - RE_OHMS * RE_OHMS;
  cal.le_mH = (x > 0) ? sqrtf(x) / (2.0f * (float)M_PI * CAL_FREQS[N_FREQS - 1]) * 1000.0f : 0;

  float ksum = 0; int kn = 0;
  for (int i = 0; i < N_FREQS - 3; i++)
    if (CAL_FREQS[i] > 2 * cal.fs && CAL_FREQS[i] <= 400) { ksum += magAcc[i]; kn++; }
  cal.plantK = kn ? ksum / kn : magAcc[N_FREQS - 4];

  float w0 = 2.0f * (float)M_PI * cal.fs;
  cal.kVel = (cal.qts > 0 && cal.plantK > 0)
           ? w0 * (1.0f / TARGET_QC - 1.0f / cal.qts) / cal.plantK : 0;
  if (cal.kVel < 0) cal.kVel = 0;
  cal.magic = CAL_MAGIC;
}

static void printReport() {
  Serial.println(F("\n=========== MFB AUTOCAL REPORT (F32) ==========="));
  Serial.println(F("  f(Hz)    |Z|rel    Acc mag   Acc ph(deg)"));
  for (int i = 0; i < N_FREQS; i++)
    Serial.printf("  %7.1f  %8.4f  %8.5f  %8.1f\n",
      CAL_FREQS[i], magZ[i], magAcc[i], phAcc[i] * 180.0f / (float)M_PI);
  Serial.println(F("------------------------------------------------"));
  Serial.printf("  Fs      = %.2f Hz\n", cal.fs);
  Serial.printf("  Re      = %.2f ohm (entered)\n", cal.re);
  Serial.printf("  r0      = %.2f\n", cal.r0);
  Serial.printf("  Qms     = %.2f\n", cal.qms);
  Serial.printf("  Qes     = %.2f\n", cal.qes);
  Serial.printf("  Qts     = %.3f\n", cal.qts);
  Serial.printf("  Le      = %.2f mH\n", cal.le_mH);
  Serial.printf("  PlantK  = %.4f\n", cal.plantK);
  Serial.printf("  k_vel   = %.4f (target Qc %.2f)\n", cal.kVel, TARGET_QC);
  Serial.printf("  Accel DC = %ld counts\n", (long)accelDC);
  Serial.println(F("  Saved to EEPROM. Entering RUN.\n"));
}

// ------------------------------- Setup / loop -------------------------------
void setup() {
  Serial.begin(115200);
  AudioMemory_F32(24, audioCfg);
  // setI2SFreq((int)FS_AUDIO);   // fallback if lib version ignores cfg rate

  adc.adc0->setResolution(12);
  adc.adc0->setAveraging(8);
  adc.adc0->setConversionSpeed(ADC_CONVERSION_SPEED::HIGH_SPEED);
  adc.adc0->setSamplingSpeed(ADC_SAMPLING_SPEED::HIGH_SPEED);
  adc.adc0->startContinuous(ACCEL_PIN);
  accelTimer.begin(accelISR, 1000000.0f / FS_AUDIO);

  delay(1500);
  while (!Serial && millis() < 4000) {}

  int64_t acc = 0; const int NDC = 12000;
  for (int i = 0; i < NDC; i++) { acc += (int32_t)adc.adc0->analogReadContinuous(); delayMicroseconds(20); }
  accelDC = (int32_t)(acc / NDC);
  Serial.printf("Accel DC: %ld counts (%.3f V)\n", (long)accelDC, accelDC * 3.3f / 4095.0f);

  Serial.println(F("AUTOCAL: stepped-sine sweep..."));
  for (int i = 0; i < N_FREQS; i++) {
    servo.calStart(CAL_FREQS[i]);
    while (!servo.calFinished()) { yield(); }
    float rM, aM, aP, cM, cP;
    servo.getCal(rM, aM, aP, cM, cP);
    magAcc[i] = (rM > 0) ? aM / rM : 0;
    phAcc[i]  = aP;
    magZ[i]   = (cM > 1e-9f) ? rM / cM : 0;
    Serial.printf("  %6.1f Hz done\n", CAL_FREQS[i]);
  }
  servo.setIdle();

  deriveParameters();
  EEPROM.put(CAL_ADDR, cal);
  printReport();
  servo.setLoop(cal.kVel, 2.0f);
}

void loop() {
  static uint32_t t = 0;
  if (millis() - t > 5000) {
    t = millis();
    Serial.printf("RUN  mem_f32=%d\n", AudioMemoryUsageMax_F32());
  }
}
