# MFB Servo Controller — Carrier PCB Design Package

Target: 2-layer JLCPCB, 100 × 80 mm, 1.6 mm FR4, HASL. All active modules socketed
on female headers; only passives and connectors soldered to the carrier.

## Assumptions (flag if wrong)
- Teensy 4.0 (the MFB build unit), socketed on 2× 14-pin + 1× 5-pin female headers
- ADXL326 stays remote in the dust cap → connects via shielded cable + JST
- INA240 as the green breakout module (onboard R100 removed), socketed
- PCM1808 and UDA1334A boards socketed on their existing header rows
- External 5 V supply; Teensy VUSB↔VIN pad cut so USB can stay plugged during dev

## Connectors
| Ref | Type | Function | Pinout |
|---|---|---|---|
| J1 | 2-pos 5.08 mm screw terminal | +5 V in | 1: +5V · 2: GND |
| J2 | RCA jack, PCB mount (or 2-pos header to panel RCA) | Analog audio in | tip: signal · shell: GND |
| J3 | JST-XH 4-pos | Accelerometer cable | 1: +5V · 2: GND · 3: Z-out · 4: shield (GND, board end only) |
| J4 | 2-pos 3.5 mm screw terminal | Shunt sense pair (twisted) | 1: IN+ (driver side) · 2: IN− (amp side) |
| J5 | 2-pos header or RCA | Line out → sub amp | from UDA1334A Lout · GND |
| J6 | 2×3 header, 2.54 mm | Debug: 3V3, GND, A0 tap, INA out tap, spare GPIO ×2 | — |

## Netlist (Teensy 4.0 audio-shield-standard pins)
```
I2S bus (shared):
  Teensy 23 (MCLK1)  -> PCM1808 SCK
  Teensy 21 (BCLK1)  -> PCM1808 BCK, UDA1334A BCLK
  Teensy 20 (LRCLK1) -> PCM1808 LRC, UDA1334A WSEL
  Teensy  8 (IN1)    <- PCM1808 OUT (DOUT)
  Teensy  7 (OUT1A)  -> UDA1334A DIN

Analog:
  J3.3 (Z-out) -> R1 junction -> Teensy A0 (pin 14)
    C1 22nF NP0 + C2 4.7nF NP0, junction to GND (ADXL 32k internal R is the R)
  J2 tip -> PCM1808 IN-L (RCA/header on module)
  INA240 OUT -> C3 1uF film -> R2 100R -> PCM1808 IN-R
  J4.1 -> INA240 IN+ ; J4.2 -> INA240 IN-
  INA240 REF1, REF2 -> GND (at module header)

Power:
  J1 -> C4 470uF/16V + C5 100nF -> 5V plane/bus
  5V -> Teensy VIN, PCM1808 VCC, UDA1334A VIN, INA240 VCC, J3.1
  PCM1808 config: FMT=I2S, MD1/MD0 = slave 256fs (check module jumpers)
  UDA1334A: PLL/SF straps default (I2S, auto rate)
```

## Placement (top view)
```
+--------------------------------------------------------------+
| J2 (RCA in)   [PCM1808 module]        [UDA1334A module]  J5  |
|                                                               |
|      I2S bus runs left-to-right under modules                 |
|                [ Teensy 4.0, USB facing board edge ]          |
|                                                               |
| J3 (accel)  C1 C2  A0 <- keep this corner analog-quiet        |
|                                                               |
| J1 (5V in) C4 C5      [INA240 module] C3 R2      J4 (sense)   |
+--------------------------------------------------------------+
```
- Bottom layer: solid GND pour, no splits. Stitch vias around board edge and
  under each module's GND pins.
- Top layer: 5 V as a wide (≥1.5 mm) routed bus from J1; signals otherwise.
- Keep zone: J3/C1/C2/A0 corner ≥15 mm from Teensy USB connector and I2S bus.
- J4 sense traces: parallel pair, side by side, straight to INA240 header.

## Routing rules
- I2S: <60 mm, 33R series terminator on MCLK at the Teensy pin if runs are long
  (add footprint R3, populate 0R initially).
- A0 net: guard with GND pour on top layer both sides.
- No trace under the Teensy crystal area (modules are socketed ~8 mm up; still,
  keep the zone under Teensy clean of analog).
- Thermal: nothing hot on board; no relief needed.

## Carrier BOM (excl. modules)
| Ref | Part | Note |
|---|---|---|
| C1 | 22 nF NP0 5 mm radial | signal filter |
| C2 | 4.7 nF NP0 | signal filter |
| C3 | 1 uF 63 V PET film (WIMA MKS2, 5 mm) | coupling |
| C4 | 470 uF 16 V radial | bulk |
| C5 | 100 nF X7R | from kit |
| R1 | — (ADXL internal 32 k) | net junction only |
| R2 | 100 R 1/4 W | isolation |
| R3 | 0 R / 33 R 0805 or axial | MCLK terminator, DNP option |
| J1–J6 | per table | — |
| Headers | female 2.54 mm strips | cut to module lengths |

## KiCad workflow (one evening)
1. New project; draw schematic from netlist above (~30 min).
2. Footprints: all standard KiCad lib (Connector_PinSocket_2.54, TerminalBlock,
   JST_XH, CP_Radial, C_Disc, RCA jack from Connector_Audio).
3. Teensy 4.0 symbol/footprint: use the official teensy_library
   (github.com/XenGi/teensy_library or KiCad official has Teensy 4.0 in
   MCU_Module lib as of v7+).
4. Board setup: 2 layers, default 0.25 mm clearance is fine; 0.5 mm min trace
   for hand-solderable comfort.
5. DRC, plot gerbers with JLCPCB preset, upload.

## Bring-up order
1. Populate power parts only; verify 5 V at every module header socket.
2. Seat Teensy alone; blink test, ADC read A0 floating vs grounded.
3. Seat ADXL cable; verify ~1.65 V midscale, tap test.
4. Seat PCM1808 + UDA1334A; I2S loopback passthrough sketch.
5. Seat INA240 last; DC cal current through J4, store scale factor.
